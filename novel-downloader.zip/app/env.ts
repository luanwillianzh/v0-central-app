// This file is used to configure environment variables
// You can set API_BASE_URL in your .env.local file

export const API_BASE_URL = process.env.API_BASE_URL || "https://central-nu.vercel.app"

